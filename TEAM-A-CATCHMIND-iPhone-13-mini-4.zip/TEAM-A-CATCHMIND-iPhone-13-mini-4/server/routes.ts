import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  app.get("/api/kakao-map-key", (_req, res) => {
    const apiKey = process.env.KAKAO_MAP_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "Kakao Map API key not configured" });
    }
    res.json({ appKey: apiKey });
  });

  const httpServer = createServer(app);

  return httpServer;
}
