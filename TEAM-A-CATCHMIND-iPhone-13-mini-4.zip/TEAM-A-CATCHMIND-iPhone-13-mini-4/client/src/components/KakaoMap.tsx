import { useEffect, useRef, useState } from "react";

declare global {
  interface Window {
    kakao: any;
  }
}

interface KakaoMapProps {
  width?: string;
  height?: string;
  latitude?: number;
  longitude?: number;
  level?: number;
  className?: string;
  markers?: Array<{
    latitude: number;
    longitude: number;
    title?: string;
  }>;
}

export function KakaoMap({
  width = "100%",
  height = "400px",
  latitude = 37.394943,
  longitude = 127.111093,
  level = 3,
  className = "",
  markers = [],
}: KakaoMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadKakaoMap = async () => {
      try {
        const response = await fetch("/api/kakao-map-key");
        if (!response.ok) {
          throw new Error("Failed to get Kakao Map API key");
        }
        const { appKey } = await response.json();

        if (window.kakao && window.kakao.maps) {
          if (window.kakao.maps.Map) {
            setIsLoaded(true);
          } else {
            window.kakao.maps.load(() => {
              setIsLoaded(true);
            });
          }
          return;
        }

        const existingScript = document.querySelector('script[src*="dapi.kakao.com"]');
        if (existingScript) {
          existingScript.remove();
        }

        const script = document.createElement("script");
        script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${appKey}&autoload=false`;
        script.async = true;

        script.onload = () => {
          if (window.kakao && window.kakao.maps) {
            window.kakao.maps.load(() => {
              setIsLoaded(true);
            });
          } else {
            setError("Kakao SDK가 올바르게 로드되지 않았습니다. Kakao Developer 콘솔에서 도메인을 등록했는지 확인해주세요.");
          }
        };

        script.onerror = () => {
          setError("Kakao Map SDK 로드 실패. Kakao Developer 콘솔에서 도메인을 등록했는지 확인해주세요.");
        };

        document.head.appendChild(script);
      } catch (err) {
        setError(err instanceof Error ? err.message : "알 수 없는 오류");
      }
    };

    loadKakaoMap();
  }, []);

  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    const options = {
      center: new window.kakao.maps.LatLng(latitude, longitude),
      level: level,
    };

    const map = new window.kakao.maps.Map(mapRef.current, options);

    markers.forEach((markerData) => {
      const markerPosition = new window.kakao.maps.LatLng(
        markerData.latitude,
        markerData.longitude
      );
      const marker = new window.kakao.maps.Marker({
        position: markerPosition,
      });
      marker.setMap(map);

      if (markerData.title) {
        const infowindow = new window.kakao.maps.InfoWindow({
          content: `<div style="padding:5px;font-size:12px;">${markerData.title}</div>`,
        });
        window.kakao.maps.event.addListener(marker, "click", () => {
          infowindow.open(map, marker);
        });
      }
    });
  }, [isLoaded, latitude, longitude, level, markers]);

  if (error) {
    return (
      <div
        className={`flex items-center justify-center bg-gray-200 ${className}`}
        style={{ width, height }}
      >
        <p className="text-red-500 text-sm">{error}</p>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div
        className={`flex items-center justify-center bg-gray-200 ${className}`}
        style={{ width, height }}
      >
        <p className="text-gray-500 text-sm">지도 로딩 중...</p>
      </div>
    );
  }

  return (
    <div
      ref={mapRef}
      className={className}
      style={{ width, height }}
    />
  );
}
