import {
  ArrowLeftIcon,
  BookmarkIcon,
  CalendarIcon,
  ChevronDownIcon,
  SlidersHorizontalIcon,
  StarIcon,
} from "lucide-react";
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { KakaoMap } from "@/components/KakaoMap";

const categoryFilters = [
  { label: "전체", count: null, active: true },
  { label: "미식", count: 664, active: false },
  { label: "문화 / 예술", count: 2436, active: false },
];

const sortFilters = [
  { icon: null, label: "추천순", variant: "outline" as const },
  { icon: SlidersHorizontalIcon, label: "필터", variant: "outline" as const },
  {
    icon: null,
    label: "내 주변",
    variant: "default" as const,
    highlighted: true,
  },
];


const placeImages = [
  { width: "w-[180px]", height: "h-[120px]" },
  { width: "w-[180px]", height: "h-[120px]" },
  { width: "w-[180px]", height: "h-[120px]" },
];

const mapMarkersData = [
  { latitude: 37.395500, longitude: 127.110500, title: "맛집 1" },
  { latitude: 37.394200, longitude: 127.109800, title: "맛집 2" },
  { latitude: 37.396100, longitude: 127.111800, title: "맛집 3" },
  { latitude: 37.393800, longitude: 127.112500, title: "바차 판교점" },
  { latitude: 37.395000, longitude: 127.113200, title: "맛집 5" },
];

export const IphoneMini = (): JSX.Element => {
  return (
    <div className="bg-white w-full min-w-[375px] min-h-[812px] relative">
      <div className="absolute top-0 left-0 w-[375px] h-[716px]">
        <KakaoMap
          width="375px"
          height="716px"
          latitude={37.394943}
          longitude={127.111093}
          level={4}
          markers={mapMarkersData}
        />
      </div>

      <header className="flex w-[375px] h-12 items-center justify-center gap-1.5 px-4 py-[11px] absolute top-0 left-0 bg-white z-20">
        <div className="flex h-[22px] items-center justify-center gap-2.5 pt-0.5 pb-0 px-0 relative flex-1 grow">
          <div className="relative w-fit mt-[-2.00px] [font-family:'SF_Pro-Semibold',Helvetica] font-normal text-black text-[17px] text-center tracking-[0] leading-[22px] whitespace-nowrap">
            9:41
          </div>
        </div>

        <div className="relative w-[125px] h-[37px] mt-[-5.50px] mb-[-5.50px] rounded-[100px]" />

        <img
          className="relative flex-1 grow h-[22px]"
          alt="Levels"
          src="/figmaAssets/levels.svg"
        />
      </header>

      <div className="flex flex-col w-[344px] items-start gap-2 absolute top-[65px] left-[15px] z-20">
        <div className="flex items-center gap-4 px-3 py-3.5 relative self-stretch w-full flex-[0_0_auto] bg-white rounded-xl border border-solid border-[#c2c2c2] shadow-[0px_0px_6px_#00000014]">
          <ArrowLeftIcon className="w-[18px] h-[18px]" />

          <div className="flex-1 [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#9e9e9e] text-base relative mt-[-1.00px] tracking-[0] leading-[normal]">
            찾고 싶은게 있나요?
          </div>

          <img
            className="relative w-px h-4"
            alt="Vector"
            src="/figmaAssets/vector-1.svg"
          />

          <div className="inline-flex items-center gap-2 relative flex-[0_0_auto]">
            <CalendarIcon className="w-[18px] h-[18px]" />

            <div className="w-fit mt-[-0.50px] [font-family:'Pretendard_Variable-Medium',Helvetica] font-medium text-[#006ce6] text-sm relative tracking-[0] leading-[normal]">
              날짜 · 인원
            </div>
          </div>
        </div>

        <div className="inline-flex items-center gap-2 relative flex-[0_0_auto]">
          {categoryFilters.map((filter, index) => (
            <Badge
              key={`filter-${index}`}
              variant={filter.active ? "default" : "outline"}
              className={`inline-flex items-center justify-center gap-${filter.count ? "1" : "2.5"} px-2.5 py-[7px] h-auto ${
                filter.active
                  ? "bg-[#222222] text-white"
                  : "bg-white text-[#5f5f5f] border-[#dfdfdf]"
              } rounded-[1000px] shadow-[0px_0px_6px_#00000014]`}
            >
              <span
                className={`${filter.count ? "mt-[-1.00px]" : "mt-[-1.00px]"} [font-family:'Pretendard_Variable-Medium',Helvetica] font-medium text-base whitespace-nowrap tracking-[0] leading-[normal]`}
              >
                {filter.label}
              </span>
              {filter.count && (
                <span className="[font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#9b9b9b] text-xs tracking-[0] leading-[normal] whitespace-nowrap">
                  {filter.count}
                </span>
              )}
            </Badge>
          ))}
        </div>
      </div>

      <section className="flex flex-col w-[374px] items-center gap-2 pt-2 pb-4 px-4 absolute left-0 bottom-0 bg-white rounded-[20px_20px_0px_0px] border-t [border-top-style:solid] border-r [border-right-style:solid] border-l [border-left-style:solid] border-[#c2c2c2] shadow-[0px_0px_6px_#00000014] z-20">
        <div className="relative w-[29px] h-1 bg-[#d9d9d9] rounded-[1000px]" />

        <button className="flex items-center gap-1 px-1 py-[5px] relative self-stretch w-full flex-[0_0_auto] rounded-[1000px]">
          <div className="relative w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-SemiBold',Helvetica] font-semibold text-black text-base tracking-[0] leading-[normal] whitespace-nowrap">
            주변 1km
          </div>
          <ChevronDownIcon className="w-[18px] h-[18px]" />
        </button>

        <div className="flex flex-col w-[342px] items-start gap-2 relative flex-[0_0_auto]">
          <div className="flex items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <Button
              variant="outline"
              className="inline-flex items-center justify-center gap-1 px-2.5 py-[9px] h-auto bg-white rounded-[1000px] border border-solid border-[#dfdfdf]"
            >
              <span className="w-fit mt-[-0.50px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#5f5f5f] text-sm tracking-[0] leading-[normal]">
                추천순
              </span>
              <ChevronDownIcon className="w-[18px] h-[18px]" />
            </Button>

            <Button
              variant="outline"
              className="inline-flex items-center justify-center gap-1 px-2.5 py-[9px] h-auto bg-white rounded-[1000px] border border-solid border-[#dfdfdf]"
            >
              <SlidersHorizontalIcon className="w-[18px] h-[18px]" />
              <span className="w-fit mt-[-0.50px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#5f5f5f] text-sm tracking-[0] leading-[normal]">
                필터
              </span>
            </Button>

            <Button
              variant="outline"
              className="inline-flex items-center justify-center gap-1 px-2.5 py-[9px] h-auto bg-[#ff68354c] rounded-[1000px] border border-solid border-[#ff3d00]"
            >
              <span className="w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#ff3d00] text-sm tracking-[0] leading-[normal]">
                내 주변
              </span>
            </Button>
          </div>
        </div>

        <div className="flex flex-col items-start gap-2 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex items-center gap-2 relative self-stretch w-full flex-[0_0_auto]">
            <h2 className="flex-1 mt-[-1.00px] [font-family:'Pretendard_Variable-SemiBold',Helvetica] font-semibold text-black text-[19px] relative tracking-[0] leading-[normal]">
              바차 판교점
            </h2>
            <BookmarkIcon className="w-[18px] h-[18px]" />
          </div>

          <div className="flex items-center gap-0.5 relative self-stretch w-full flex-[0_0_auto]">
            <StarIcon className="w-3 h-3 fill-current" />
            <div className="w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-SemiBold',Helvetica] font-semibold text-black text-sm relative tracking-[0] leading-[normal]">
              4.8
            </div>
            <div className="relative w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#5f5f5f] text-sm tracking-[0] leading-[normal]">
              (24)
            </div>
            <div className="w-fit [font-family:'Pretendard_Variable-Medium',Helvetica] font-medium text-[#5f5f5f] text-sm relative mt-[-1.00px] tracking-[0] leading-[normal]">
              ·
            </div>
            <div className="relative w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#5f5f5f] text-sm tracking-[0] leading-[normal]">
              판교
            </div>
            <div className="w-fit [font-family:'Pretendard_Variable-Medium',Helvetica] font-medium text-[#5f5f5f] text-sm relative mt-[-1.00px] tracking-[0] leading-[normal]">
              ·
            </div>
            <div className="relative w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#5f5f5f] text-sm tracking-[0] leading-[normal]">
              요리주점
            </div>
            <div className="w-fit [font-family:'Pretendard_Variable-Medium',Helvetica] font-medium text-[#5f5f5f] text-sm relative mt-[-1.00px] tracking-[0] leading-[normal]">
              ·
            </div>
            <div className="relative w-fit mt-[-1.00px] [font-family:'Pretendard_Variable-Regular',Helvetica] font-normal text-[#5f5f5f] text-sm tracking-[0] leading-[normal]">
              내 위치에서 730m
            </div>
          </div>

          <div className="inline-flex items-start gap-0.5 relative flex-[0_0_auto] mr-[-202.00px] rounded-xl overflow-hidden">
            {placeImages.map((image, index) => (
              <div
                key={`image-${index}`}
                className={`relative ${image.width} ${image.height} bg-[#e2e2e2]`}
              />
            ))}
          </div>
        </div>
      </section>

    </div>
  );
};
