[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Verify the project is working using the feedback tool
[x] 4. Kakao Map API integration completed
[x] 5. Fixed z-index for UI components to appear above map